process to run the Program:

1.) Open Eclipse for Web developers
2.) CLick on file on the top menu and click on new and select dynamic web project
3.) provide any name for the project and select apache tomcat server 
4.) Now Expand the project and go to Webapp folder under the src folder
5.) Copy all the script files and right click on web app and click on paster
6.) Make sure to save all the files under web app( don't paste under WEB-INF) folder
7.) Now open the Homepage.HTML and right click and select run on tomcat Server
8.) THe front end home page is loaded and enter any data as requested and communicated data is shown in the output.