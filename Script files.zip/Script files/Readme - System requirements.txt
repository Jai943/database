System Requirements :-

windows 8.1 or later
RAM memory - 4GB or Higher
SSH needs to be installed if need be to check the sql queries in the omega server

Software Requirements:-

1.) Apache tomcat server 10.0 or higher required
	download Link -----------> https://tomcat.apache.org/download-80.cgi
	youtube Link for help ----> https://www.youtube.com/watch?v=pKMgr8uNvGM

2.) Eclipse IDE for JAVA Web Developers is required to check the outputs
	download link -----------> https://www.eclipse.org/downloads/packages/release/indigo/sr2/eclipse-ide-javascript-web-developers
	tomcat connection to Eclipse ---> https://www.javatpoint.com/how-to-configure-tomcat-server-in-eclipse-ide
