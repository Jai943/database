WAR file:


These files are exported from Eclipse as a complete project 

You can go to eclipse and just import these from the file menu.

Mydata.war file containts the code for the reports generated
PIDS.war file containts the code required to run the hospital database.