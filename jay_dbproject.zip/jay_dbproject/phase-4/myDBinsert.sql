SQL> insert into F21_S003_9_PATIENT (PatientName,Birth_date,Contact,gender,EMAIL) values ('Burks, Rosella',TO_DATE('1996-08-18','YYYY-MM-DD'),17187281901,'f','BurksR@gmail.com');

1 row created.

SQL> insert into F21_S003_9_PATIENT (PatientName,Birth_date,Contact,gender,EMAIL) values ('Avila, Damien',TO_DATE('1998-07-21','YYYY-MM-DD'),18809988032,'m','AvilaD@gmail.com');

1 row created.

SQL> insert into F21_S003_9_PATIENT (PatientName,Birth_date,Contact,gender,EMAIL) values ('Olsen, Robin',TO_DATE('1987-02-23','YYYY-MM-DD'),17340966731,'m','OlsenR@gmail.com');

1 row created.

SQL> insert into F21_S003_9_PATIENT (PatientName,Birth_date,Contact,gender,EMAIL) values ('Moises, Edgar Estes',TO_DATE('1969-08-16','YYYY-MM-DD'),14388924048,'m','MoisesE@gmail.com');

1 row created.

SQL> insert into F21_S003_9_PATIENT (PatientName,Birth_date,Contact,gender,EMAIL) values ('Brian, Heath Pruitt',TO_DATE('1966-02-27','YYYY-MM-DD'),14356189857,'m','BrianH@gmail.com');

1 row created.

SQL> insert into F21_S003_9_PATIENT (PatientName,Birth_date,Contact,gender,EMAIL) values ('Claude, Elvin Haney',TO_DATE('1987-05-09','YYYY-MM-DD'),17160886256,'m','ClaudeE@gmail.com');

1 row created.

SQL> insert into F21_S003_9_PATIENT (PatientName,Birth_date,Contact,gender,EMAIL) values ('Mosley, Edmund',TO_DATE('1971-03-11','YYYY-MM-DD'),19172732142,'m','MosleyE@gmail.com');

1 row created.

SQL> insert into F21_S003_9_PATIENT (PatientName,Birth_date,Contact,gender,EMAIL) values ('Derek, Antoine Mccoy',TO_DATE('1969-04-04','YYYY-MM-DD'),13791893452,'m','DerekA@gmail.com');

1 row created.

SQL> insert into F21_S003_9_PATIENT (PatientName,Birth_date,Contact,gender,EMAIL) values ('Hawkins, Callie',TO_DATE('1968-11-02','YYYY-MM-DD'),11355099403,'f','HawkinsC@gmail.com');

1 row created.

SQL> insert into F21_S003_9_PATIENT (PatientName,Birth_date,Contact,gender,EMAIL) values ('Pate, Andrea',TO_DATE('1991-01-09','YYYY-MM-DD'),19629928796,'f','PateA@gmail.com');

1 row created.

SQL> insert into F21_S003_9_PATIENT (PatientName,Birth_date,Contact,gender,EMAIL) values ('Austin, Liz',TO_DATE('1981-09-11','YYYY-MM-DD'),18468062474,'f','AustinL@gmail.com');

1 row created.

SQL> insert into F21_S003_9_PATIENT (PatientName,Birth_date,Contact,gender,EMAIL) values ('Kendrick, Reba Alford',TO_DATE('1991-07-21','YYYY-MM-DD'),12443075228,'f','KendrickR@gmail.com');

1 row created.

SQL> insert into F21_S003_9_PATIENT (PatientName,Birth_date,Contact,gender,EMAIL) values ('Sims, Angelina',TO_DATE('1970-10-11','YYYY-MM-DD'),13143995646,'f','SimsA@gmail.com');

1 row created.

SQL> insert into F21_S003_9_PATIENT (PatientName,Birth_date,Contact,gender,EMAIL) values ('Mullins, Kimberly',TO_DATE('1961-07-15','YYYY-MM-DD'),11282206302,'m','MullinsK@gmail.com');

1 row created.

SQL> insert into F21_S003_9_PATIENT (PatientName,Birth_date,Contact,gender,EMAIL) values ('Chuck, Lloyd Haney',TO_DATE('1983-11-19','YYYY-MM-DD'),13585938942,'m','ChuckL@gmail.com');

1 row created.

SQL> insert into F21_S003_9_PATIENT (PatientName,Birth_date,Contact,gender,EMAIL) values ('Payne, Ladonna',TO_DATE('1978-10-30','YYYY-MM-DD'),18186582726,'f','PayneL@gmail.com');

1 row created.

SQL> insert into F21_S003_9_PATIENT (PatientName,Birth_date,Contact,gender,EMAIL) values ('Baxter, Johnathan Browning',TO_DATE('1967-07-09','YYYY-MM-DD'),13856120033,'m','BaxterJ@gmail.com');

1 row created.

SQL> insert into F21_S003_9_PATIENT (PatientName,Birth_date,Contact,gender,EMAIL) values ('Weiss, Gilbert',TO_DATE('1999-05-11','YYYY-MM-DD'),13970927726,'m','WeissG@gmail.com');

1 row created.

SQL> insert into F21_S003_9_PATIENT (PatientName,Birth_date,Contact,gender,EMAIL) values ('Deirdre, Florence Barrera',TO_DATE('1981-07-06','YYYY-MM-DD'),15998950657,'m','DeirdreF@gmail.com');

1 row created.

SQL> insert into F21_S003_9_PATIENT (PatientName,Birth_date,Contact,gender,EMAIL) values ('Fernando, Toby Calderon',TO_DATE('1960-01-02','YYYY-MM-DD'),19663180337,'m','FernandoT@gmail.com');

1 row created.

SQL> insert into F21_S003_9_PATIENT (PatientName,Birth_date,Contact,gender,EMAIL) values ('Garrison, Patrica',TO_DATE('1999-12-02','YYYY-MM-DD'),15215584643,'f','GarrisonP@gmail.com');

1 row created.

SQL> insert into F21_S003_9_PATIENT (PatientName,Birth_date,Contact,gender,EMAIL) values ('Effie, Leila Vinson',TO_DATE('1972-11-06','YYYY-MM-DD'),16981940277,'f','EffieL@gmail.com');

1 row created.

SQL> insert into F21_S003_9_PATIENT (PatientName,Birth_date,Contact,gender,EMAIL) values ('Buckley, Rose',TO_DATE('1977-06-24','YYYY-MM-DD'),18095795712,'f','BuckleyR@gmail.com');

1 row created.

SQL> insert into F21_S003_9_PATIENT (PatientName,Birth_date,Contact,gender,EMAIL) values ('Stanton, Kathie',TO_DATE('1967-12-12','YYYY-MM-DD'),12675447367,'f','StantonK@gmail.com');

1 row created.

SQL> insert into F21_S003_9_PATIENT (PatientName,Birth_date,Contact,gender,EMAIL) values ('Banks, Shannon',TO_DATE('1969-02-17','YYYY-MM-DD'),12244699461,'m','BanksS@gmail.com');

1 row created.

SQL> insert into F21_S003_9_PATIENT (PatientName,Birth_date,Contact,gender,EMAIL) values ('Barnes, Cleo',TO_DATE('1986-11-07','YYYY-MM-DD'),13846259708,'m','BarnesC@gmail.com');

1 row created.

SQL> insert into F21_S003_9_PATIENT (PatientName,Birth_date,Contact,gender,EMAIL) values ('Brady, Nellie',TO_DATE('1968-11-10','YYYY-MM-DD'),18946382625,'f','BradyN@gmail.com');

1 row created.

SQL> insert into F21_S003_9_PATIENT (PatientName,Birth_date,Contact,gender,EMAIL) values ('Katheryn, Ruben Holt',TO_DATE('1960-11-25','YYYY-MM-DD'),12213536720,'m','KatherynR@gmail.com');

1 row created.

SQL> insert into F21_S003_9_PATIENT (PatientName,Birth_date,Contact,gender,EMAIL) values ('Michael, Dianne',TO_DATE('1976-01-04','YYYY-MM-DD'),19593201850,'f','MichaelD@gmail.com');

1 row created.

SQL> insert into F21_S003_9_PATIENT (PatientName,Birth_date,Contact,gender,EMAIL) values ('Grant, Adam',TO_DATE('1998-12-02','YYYY-MM-DD'),12360723416,'m','GrantA@gmail.com');

1 row created.

SQL> insert into F21_S003_9_PATIENT (PatientName,Birth_date,Contact,gender,EMAIL) values ('Head, Kurtis',TO_DATE('1979-09-21','YYYY-MM-DD'),11890343908,'m','HeadK@gmail.com');

1 row created.

SQL> insert into F21_S003_9_PATIENT (PatientName,Birth_date,Contact,gender,EMAIL) values ('Berger, Jami',TO_DATE('1987-06-05','YYYY-MM-DD'),14746876198,'f','BergerJ@gmail.com');

1 row created.

SQL> insert into F21_S003_9_PATIENT (PatientName,Birth_date,Contact,gender,EMAIL) values ('Earline, Jaime Fitzgerald',TO_DATE('1991-05-29','YYYY-MM-DD'),12551786472,'m','EarlineJ@gmail.com');

1 row created.

SQL> insert into F21_S003_9_PATIENT (PatientName,Birth_date,Contact,gender,EMAIL) values ('Evelyn, Summer Frost',TO_DATE('1991-10-16','YYYY-MM-DD'),12393238459,'m','EvelynS@gmail.com');

1 row created.

SQL> insert into F21_S003_9_PATIENT (PatientName,Birth_date,Contact,gender,EMAIL) values ('Quentin, Sam Hyde',TO_DATE('1962-02-13','YYYY-MM-DD'),17743249837,'m','QuentinS@gmail.com');

1 row created.

SQL> insert into F21_S003_9_PATIENT (PatientName,Birth_date,Contact,gender,EMAIL) values ('Dunlap, Ann',TO_DATE('1967-10-14','YYYY-MM-DD'),17667123306,'f','DunlapA@gmail.com');

1 row created.

SQL> insert into F21_S003_9_PATIENT (PatientName,Birth_date,Contact,gender,EMAIL) values ('Shields, Rich Pena',TO_DATE('1964-06-14','YYYY-MM-DD'),15832860205,'m','ShieldsR@gmail.com');

1 row created.

SQL> insert into F21_S003_9_PATIENT (PatientName,Birth_date,Contact,gender,EMAIL) values ('Page, Winnie',TO_DATE('1976-12-09','YYYY-MM-DD'),17697362438,'f','PageW@gmail.com');

1 row created.

SQL> insert into F21_S003_9_PATIENT (PatientName,Birth_date,Contact,gender,EMAIL) values ('Sparks, Ezra',TO_DATE('1960-02-25','YYYY-MM-DD'),15750935394,'f','SparksE@gmail.com');

1 row created.

SQL> insert into F21_S003_9_PATIENT (PatientName,Birth_date,Contact,gender,EMAIL) values ('Kaufman, Elba',TO_DATE('1984-07-01','YYYY-MM-DD'),19281625041,'m','KaufmanE@gmail.com');
  2  --inserting the values to the patient table

1 row created.

SQL> 
SQL> spool off;          
SQL> insert into F21_S003_9_DOCTOR (DOC_NAME,DOC_CONTACT) values ('Dr. Sonal Jani',16566123565);

1 row created.

SQL> insert into F21_S003_9_DOCTOR (DOC_NAME,DOC_CONTACT) values ('Dr. Kenneth Giedd',16367270228);

1 row created.

SQL> insert into F21_S003_9_DOCTOR (DOC_NAME,DOC_CONTACT) values ('Dr. Cheryl Cottrol',12896523269);

1 row created.

SQL> insert into F21_S003_9_DOCTOR (DOC_NAME,DOC_CONTACT) values ('Dr. Jeffrey Ahn',15168093770);

1 row created.

SQL> insert into F21_S003_9_DOCTOR (DOC_NAME,DOC_CONTACT) values ('Dr. Aditya ',12073970543);

1 row created.

SQL> insert into F21_S003_9_DOCTOR (DOC_NAME,DOC_CONTACT) values ('Dr. Ronaldo ',14515632602);

1 row created.

SQL> insert into F21_S003_9_DOCTOR (DOC_NAME,DOC_CONTACT) values ('Dr. Messi ',17605986112);

1 row created.

SQL> insert into F21_S003_9_DOCTOR (DOC_NAME,DOC_CONTACT) values ('Dr. Madeleine Schaberg',14991637602);

1 row created.

SQL> insert into F21_S003_9_DOCTOR (DOC_NAME,DOC_CONTACT) values ('Dr. Jason Deutsch',11971066669);

1 row created.

SQL> insert into F21_S003_9_DOCTOR (DOC_NAME,DOC_CONTACT) values ('Dr. Daniela Lipovic',17939136745);

1 row created.

SQL> insert into F21_S003_9_DOCTOR (DOC_NAME,DOC_CONTACT) values ('Dr. D. Timothy Culotta',17696438460);

1 row created.

SQL> insert into F21_S003_9_DOCTOR (DOC_NAME,DOC_CONTACT) values ('Dr. Oleg Goncharov',15925725894);

1 row created.

SQL> insert into F21_S003_9_DOCTOR (DOC_NAME,DOC_CONTACT) values ('Dr. Sean Lager',15285810677);

1 row created.

SQL> insert into F21_S003_9_DOCTOR (DOC_NAME,DOC_CONTACT) values ('Dr. Jeffrey Yormak',19056704757);
  2  --inserting the values to the doctor table

1 row created.

SQL> 
SQL> spool
currently spooling to myDBinsert.sql
SQL> SPOOL OFF;
SQL> insert into F21_S003_9_DOC_SPEC (SPEC_NAME,SPEC_TYPE,DOCTOR_ID) values ('Cardiologist','Heart',201);

1 row created.

SQL> insert into F21_S003_9_DOC_SPEC (SPEC_NAME,SPEC_TYPE,DOCTOR_ID) values ('Cardiologist','Heart',202);

1 row created.

SQL> insert into F21_S003_9_DOC_SPEC (SPEC_NAME,SPEC_TYPE,DOCTOR_ID) values ('Neurologist','Neuro',203);

1 row created.

SQL> insert into F21_S003_9_DOC_SPEC (SPEC_NAME,SPEC_TYPE,DOCTOR_ID) values ('Ear_Nose_Throat Doctor','ENT',204);

1 row created.

SQL> insert into F21_S003_9_DOC_SPEC (SPEC_NAME,SPEC_TYPE,DOCTOR_ID) values ('Ear_Nose_Throat Doctor','ENT',205);

1 row created.

SQL> insert into F21_S003_9_DOC_SPEC (SPEC_NAME,SPEC_TYPE,DOCTOR_ID) values ('Medicine Physician','General',206);

1 row created.

SQL> insert into F21_S003_9_DOC_SPEC (SPEC_NAME,SPEC_TYPE,DOCTOR_ID) values ('Medicine Physician','General',207);

1 row created.

SQL> insert into F21_S003_9_DOC_SPEC (SPEC_NAME,SPEC_TYPE,DOCTOR_ID) values ('Medicine Physician','General',208);

1 row created.

SQL> insert into F21_S003_9_DOC_SPEC (SPEC_NAME,SPEC_TYPE,DOCTOR_ID) values ('Medicine Physician','General',209);

1 row created.

SQL> insert into F21_S003_9_DOC_SPEC (SPEC_NAME,SPEC_TYPE,DOCTOR_ID) values ('Medicine Physician','General',210);

1 row created.

SQL> insert into F21_S003_9_DOC_SPEC (SPEC_NAME,SPEC_TYPE,DOCTOR_ID) values ('Dentist','Teeth',211);

1 row created.

SQL> insert into F21_S003_9_DOC_SPEC (SPEC_NAME,SPEC_TYPE,DOCTOR_ID) values ('Dentist','Teeth',212);

1 row created.

SQL> insert into F21_S003_9_DOC_SPEC (SPEC_NAME,SPEC_TYPE,DOCTOR_ID) values ('Orthopedic ','Bones',213);

1 row created.

SQL> insert into F21_S003_9_DOC_SPEC (SPEC_NAME,SPEC_TYPE,DOCTOR_ID) values ('Orthopedic ','Bones',214);
  2  --inserting the values to the DOC_SPEC table

1 row created.

SQL> 
SQL> Spool off;
SQL> insert into F21_S003_9_DISEASE (Disease_name,Disease_description) values ('Chest Pain','Chest pain may be a symptom coronary artery disease asthma pneumonia muscle strain anxiety or digestive problems (e.g. heartburn ulcers or gallstones');

1 row created.

SQL> insert into F21_S003_9_DISEASE (Disease_name,Disease_description) values ('Coronary artery disease','Narrowing of the arteries that supply blood to the heart due to the buildup of plaque in the artery wall. The reduced blood flow to the heart can cause heart failure.');

1 row created.

SQL> insert into F21_S003_9_DISEASE (Disease_name,Disease_description) values ('Migraine','A severe recurring headache often paired with nausea and disturbed vision.');

1 row created.

SQL> insert into F21_S003_9_DISEASE (Disease_name,Disease_description) values ('Ear infection','An ear infection occurs when a bacterial or viral infection affects the middle ear symptoms include Mild pain inside ear hearing loss pus-like ear drainage');

1 row created.

SQL> insert into F21_S003_9_DISEASE (Disease_name,Disease_description) values ('Cholesteatoma','Cholesteatoma is a type of skin cyst that is located in the middle ear and mastoid bone in the skull');

1 row created.

SQL> insert into F21_S003_9_DISEASE (Disease_name,Disease_description) values ('Hypothyroidism','Hypothyroidism is a condition in which your thyroid gland doesnt produce enough of certain crucial hormones. Over time it can cause a number of health problems');

1 row created.

SQL> insert into F21_S003_9_DISEASE (Disease_name,Disease_description) values ('Fever ','A fever is a body temperature that is higher than normal. A normal temperature_ 98.6 °F (37 °C)');

1 row created.

SQL> insert into F21_S003_9_DISEASE (Disease_name,Disease_description) values ('Cold and Flu','The symptoms of cold and flu can include fever or feeling feverish/chills cough sore throat runny or stuffy nose muscle or body aches headaches and fatigue.');

1 row created.

SQL> insert into F21_S003_9_DISEASE (Disease_name,Disease_description) values ('Dehydration','Dehydration occurs when you use or lose more fluid than you take in and your body Symptoms include Extreme thirst Fatigue Dizziness');

1 row created.

SQL> insert into F21_S003_9_DISEASE (Disease_name,Disease_description) values ('Rashes','The popular term for a group of spots or red  that is usually a symptom of an underlying condition or disorder symptoms include mild itchy red rash may occur days to weeks after taking a drug');

1 row created.

SQL> insert into F21_S003_9_DISEASE (Disease_name,Disease_description) values ('Diabetes','Diabetes is a chronic health condition that affects how your body turns food into energy. Symptoms include Urinate (pee) a lot. Lose weight without trying Have blurry vision and very dry skin');

1 row created.

SQL> insert into F21_S003_9_DISEASE (Disease_name,Disease_description) values ('Cavities','Cavities are permanently damaged areas in the hard surface of your teeth that develop into tiny openings or holes  symptoms  Toothache_Mild to sharp pain Brown black or white staining');

1 row created.

SQL> insert into F21_S003_9_DISEASE (Disease_name,Disease_description) values ('Periodontitis','Periodontitis is a severe gum infection that can lead to tooth loss and other serious health complications symptoms are Bad breath or bad taste that wont go away ');

1 row created.

SQL> insert into F21_S003_9_DISEASE (Disease_name,Disease_description) values ('Arthritis','Arthritis is the swelling and tenderness of one or more joints. The main symptoms of arthritis are joint pain and stiffness fatigue and dizziness');

1 row created.

SQL> insert into F21_S003_9_DISEASE (Disease_name,Disease_description) values ('Fracture','A fracture is a break usually in a bone. If the broken bone punctures the skin it is called an open or compound fracture');
  2  --inserting the values to the Disease table

1 row created.

SQL> 
SQL> Spool off;
SQL> insert into F21_S003_9_MED_NAME(M_NAME,DESCRIPTION,PRICE_USD) values ('Tylenol','To reduce Fever and relieve pain caused by conditions such as cold flu.',35);

1 row created.

SQL> insert into F21_S003_9_MED_NAME(M_NAME,DESCRIPTION,PRICE_USD) values ('Hydralyte','It helps to stop headaches fatigue irritability etc',25);

1 row created.

SQL> insert into F21_S003_9_MED_NAME(M_NAME,DESCRIPTION,PRICE_USD) values ('Florasone Cream','It gives relief for  itching eczema and rashes etc',31);

1 row created.

SQL> insert into F21_S003_9_MED_NAME(M_NAME,DESCRIPTION,PRICE_USD) values ('Burst Oral Probiotics','It reduces bacteria that produce bad breath and supports healthy gums.',26);

1 row created.

SQL> insert into F21_S003_9_MED_NAME(M_NAME,DESCRIPTION,PRICE_USD) values ('Perio Gel','It helps in whitening the teeth and kills gum_disease causing bacteria.',14);

1 row created.

SQL> insert into F21_S003_9_MED_NAME(M_NAME,DESCRIPTION,PRICE_USD) values ('Arnicare Tab','It helps to relieve muscle pain and stiffness and to reduce pain swelling etc',25);

1 row created.

SQL> insert into F21_S003_9_MED_NAME(M_NAME,DESCRIPTION,PRICE_USD) values ('Ibuprofen','It helps in relieving pain and prevent fractured bones from healing.',34);

1 row created.

SQL> insert into F21_S003_9_MED_NAME(M_NAME,DESCRIPTION,PRICE_USD) values ('Mucinex','It helps to get relief in chest congestion',28);

1 row created.

SQL> insert into F21_S003_9_MED_NAME(M_NAME,DESCRIPTION,PRICE_USD) values ('Excedrin','It helps to get relief from headaches',29);

1 row created.

SQL> insert into F21_S003_9_MED_NAME(M_NAME,DESCRIPTION,PRICE_USD) values ('Hylands Earache drops','It helps to get relief from allergies ear pain cold and flu',13);

1 row created.

SQL> insert into F21_S003_9_MED_NAME(M_NAME,DESCRIPTION,PRICE_USD) values ('Polysporin','It helps to get relief from ear pain and allergies.',30);

1 row created.

SQL> insert into F21_S003_9_MED_NAME(M_NAME,DESCRIPTION,PRICE_USD) values ('Hypothyroidism','It helps to get relief from thyroid infection',12);

1 row created.

SQL> insert into F21_S003_9_MED_NAME(M_NAME,DESCRIPTION,PRICE_USD) values ('Levoxyl','It reduces the throat infection',20);

1 row created.

SQL> insert into F21_S003_9_MED_NAME(M_NAME,DESCRIPTION,PRICE_USD) values ('Advil','It treats fever and mild to severe pain',18);

1 row created.

SQL> insert into F21_S003_9_MED_NAME(M_NAME,DESCRIPTION,PRICE_USD) values ('Triz','To reduce Fever and relieve pain caused by conditions such as cold flu',37);

1 row created.

SQL> insert into F21_S003_9_MED_NAME(M_NAME,DESCRIPTION,PRICE_USD) values ('Vepan','It helps to stop headaches fatigue irritability etc',35);

1 row created.

SQL> insert into F21_S003_9_MED_NAME(M_NAME,DESCRIPTION,PRICE_USD) values ('Globen - G','It gives relief in itching eczema rashes etc',21);

1 row created.

SQL> insert into F21_S003_9_MED_NAME(M_NAME,DESCRIPTION,PRICE_USD) values ('Zintac','It reduces bacteria that produce bad breath and supports healthy gums.',23);

1 row created.

SQL> insert into F21_S003_9_MED_NAME(M_NAME,DESCRIPTION,PRICE_USD) values ('Sherlon','It helps in whitening the teeth and kills gum-disease causing bacteria.',34);

1 row created.

SQL> insert into F21_S003_9_MED_NAME(M_NAME,DESCRIPTION,PRICE_USD) values ('Althrocin','It helps to relieve muscle pain and stiffness and to reduce pain swelling etc',21);

1 row created.

SQL> insert into F21_S003_9_MED_NAME(M_NAME,DESCRIPTION,PRICE_USD) values ('Ranidom','It helps in relieving pain and prevent fractured bones from healing.',10);

1 row created.

SQL> insert into F21_S003_9_MED_NAME(M_NAME,DESCRIPTION,PRICE_USD) values ('Jonac Plus','It helps to get relief in chest congestion',28);

1 row created.

SQL> insert into F21_S003_9_MED_NAME(M_NAME,DESCRIPTION,PRICE_USD) values ('Omez','It helps to get relief from headaches',9);

1 row created.

SQL> insert into F21_S003_9_MED_NAME(M_NAME,DESCRIPTION,PRICE_USD) values ('Ciplac','It helps to get relief from allergies ear pain cold and flu',22);

1 row created.

SQL> insert into F21_S003_9_MED_NAME(M_NAME,DESCRIPTION,PRICE_USD) values ('Neapon','It helps to get relief from ear pain and allergies.',10);

1 row created.

SQL> insert into F21_S003_9_MED_NAME(M_NAME,DESCRIPTION,PRICE_USD) values ('Ranispas','It helps to get relief from thyroid infection',23);

1 row created.

SQL> insert into F21_S003_9_MED_NAME(M_NAME,DESCRIPTION,PRICE_USD) values ('Stodil','It reduces the throat infection',19);

1 row created.

SQL> insert into F21_S003_9_MED_NAME(M_NAME,DESCRIPTION,PRICE_USD) values ('Dolo - 650','It treats fever and mild to severe pain',6);
  2  --inserting the values to the MED_NAME table

1 row created.

SQL> 
SQL> Spool off;
SQL> insert into F21_S003_9_MEDICINE (M_NAME,MFG_DATE,QUANTITY) values ('Tylenol',TO_DATE('2021-03-20','YYYY-MM-DD'),10);

1 row created.

SQL> insert into F21_S003_9_MEDICINE (M_NAME,MFG_DATE,QUANTITY) values ('Hydralyte',TO_DATE('2021-05-13','YYYY-MM-DD'),15);

1 row created.

SQL> insert into F21_S003_9_MEDICINE (M_NAME,MFG_DATE,QUANTITY) values ('Florasone Cream',TO_DATE('2021-01-22','YYYY-MM-DD'),5);

1 row created.

SQL> insert into F21_S003_9_MEDICINE (M_NAME,MFG_DATE,QUANTITY) values ('Burst Oral Probiotics',TO_DATE('2021-02-02','YYYY-MM-DD'),25);

1 row created.

SQL> insert into F21_S003_9_MEDICINE (M_NAME,MFG_DATE,QUANTITY) values ('Perio Gel',TO_DATE('2021-07-12','YYYY-MM-DD'),30);

1 row created.

SQL> insert into F21_S003_9_MEDICINE (M_NAME,MFG_DATE,QUANTITY) values ('Arnicare Tab',TO_DATE('2021-10-07','YYYY-MM-DD'),35);

1 row created.

SQL> insert into F21_S003_9_MEDICINE (M_NAME,MFG_DATE,QUANTITY) values ('Ibuprofen',TO_DATE('2021-11-11','YYYY-MM-DD'),40);

1 row created.

SQL> insert into F21_S003_9_MEDICINE (M_NAME,MFG_DATE,QUANTITY) values ('Mucinex',TO_DATE('2021-09-09','YYYY-MM-DD'),50);

1 row created.

SQL> insert into F21_S003_9_MEDICINE (M_NAME,MFG_DATE,QUANTITY) values ('Excedrin',TO_DATE('2021-07-04','YYYY-MM-DD'),25);

1 row created.

SQL> insert into F21_S003_9_MEDICINE (M_NAME,MFG_DATE,QUANTITY) values ('Hylands Ear drops',TO_DATE('2021-06-02','YYYY-MM-DD'),15);
insert into F21_S003_9_MEDICINE (M_NAME,MFG_DATE,QUANTITY) values ('Hylands Ear drops',TO_DATE('2021-06-02','YYYY-MM-DD'),15)
*
ERROR at line 1:
ORA-02291: integrity constraint (JXJ4536.SYS_C00398827) violated - parent key 
not found 


SQL> insert into F21_S003_9_MEDICINE (M_NAME,MFG_DATE,QUANTITY) values ('Polysporin',TO_DATE('2021-04-10','YYYY-MM-DD'),50);

1 row created.

SQL> insert into F21_S003_9_MEDICINE (M_NAME,MFG_DATE,QUANTITY) values ('Hypothyroidism',TO_DATE('2021-05-10','YYYY-MM-DD'),10);

1 row created.

SQL> insert into F21_S003_9_MEDICINE (M_NAME,MFG_DATE,QUANTITY) values ('Levoxyl',TO_DATE('2021-01-01','YYYY-MM-DD'),7);

1 row created.

SQL> insert into F21_S003_9_MEDICINE (M_NAME,MFG_DATE,QUANTITY) values ('Advil',TO_DATE('2021-08-17','YYYY-MM-DD'),20);

1 row created.

SQL> insert into F21_S003_9_MEDICINE (M_NAME,MFG_DATE,QUANTITY) values ('Triz',TO_DATE('2021-09-12','YYYY-MM-DD'),22);

1 row created.

SQL> insert into F21_S003_9_MEDICINE (M_NAME,MFG_DATE,QUANTITY) values ('Vepan',TO_DATE('2021-02-11','YYYY-MM-DD'),34);

1 row created.

SQL> insert into F21_S003_9_MEDICINE (M_NAME,MFG_DATE,QUANTITY) values ('Globen - G',TO_DATE('2021-03-13','YYYY-MM-DD'),55);

1 row created.

SQL> insert into F21_S003_9_MEDICINE (M_NAME,MFG_DATE,QUANTITY) values ('Zintac',TO_DATE('2021-10-15','YYYY-MM-DD'),11);

1 row created.

SQL> insert into F21_S003_9_MEDICINE (M_NAME,MFG_DATE,QUANTITY) values ('Sherlon',TO_DATE('2021-11-13','YYYY-MM-DD'),25);

1 row created.

SQL> insert into F21_S003_9_MEDICINE (M_NAME,MFG_DATE,QUANTITY) values ('Althrocin',TO_DATE('2021-07-25','YYYY-MM-DD'),35);

1 row created.

SQL> insert into F21_S003_9_MEDICINE (M_NAME,MFG_DATE,QUANTITY) values ('Ranidom',TO_DATE('2021-05-24','YYYY-MM-DD'),45);

1 row created.

SQL> insert into F21_S003_9_MEDICINE (M_NAME,MFG_DATE,QUANTITY) values ('Jonac plus',TO_DATE('2021-06-22','YYYY-MM-DD'),55);
insert into F21_S003_9_MEDICINE (M_NAME,MFG_DATE,QUANTITY) values ('Jonac plus',TO_DATE('2021-06-22','YYYY-MM-DD'),55)
*
ERROR at line 1:
ORA-02291: integrity constraint (JXJ4536.SYS_C00398827) violated - parent key 
not found 


SQL> insert into F21_S003_9_MEDICINE (M_NAME,MFG_DATE,QUANTITY) values ('Omez',TO_DATE('2021-03-31','YYYY-MM-DD'),40);

1 row created.

SQL> insert into F21_S003_9_MEDICINE (M_NAME,MFG_DATE,QUANTITY) values ('Ciplac',TO_DATE('2021-02-28','YYYY-MM-DD'),25);

1 row created.

SQL> insert into F21_S003_9_MEDICINE (M_NAME,MFG_DATE,QUANTITY) values ('Neapon',TO_DATE('2021-04-13','YYYY-MM-DD'),35);

1 row created.

SQL> insert into F21_S003_9_MEDICINE (M_NAME,MFG_DATE,QUANTITY) values ('Ranispas',TO_DATE('2021-01-19','YYYY-MM-DD'),15);

1 row created.

SQL> insert into F21_S003_9_MEDICINE (M_NAME,MFG_DATE,QUANTITY) values ('Stodil',TO_DATE('2021-09-22','YYYY-MM-DD'),20);

1 row created.

SQL> insert into F21_S003_9_MEDICINE (M_NAME,MFG_DATE,QUANTITY) values ('Dolo - 650',TO_DATE('2021-11-23','YYYY-MM-DD'),30);
  2  --inserting the values to the MEDICINE table

1 row created.

SQL> 
SQL> 
SQL> Spool off;
SQL> insert into F21_S003_9_MEDICINE (M_NAME,MFG_DATE,QUANTITY) values ('Jonac Plus',TO_DATE('2021-06-22','YYYY-MM-DD'),55);

1 row created.

SQL> insert into F21_S003_9_MEDICINE (M_NAME,MFG_DATE,QUANTITY) values ('Hylands Earache drops',TO_DATE('2021-06-02','YYYY-MM-DD'),15);

1 row created.

SQL> ​​insert into F21_S003_9_MEDICINE (M_NAME,MFG_DATE,QUANTITY) values ('Tylenol',TO_DATE('2021-03-20','YYYY-MM-DD'),10);
SP2-0734: unknown command beginning "​​inse..." - rest of line ignored.
SQL> insert into F21_S003_9_MEDICINE (M_NAME,MFG_DATE,QUANTITY) values ('Tylenol',TO_DATE('2021-03-20','YYYY-MM-DD'),10);

1 row created.

SQL> Spool off;
SQL> insert into F21_S003_9_MED_NAME(M_NAME,DESCRIPTION,PRICE_USD) values ('Pramlintide','It treats diabetes',16);

1 row created.

SQL> insert into F21_S003_9_MED_NAME(M_NAME,DESCRIPTION,PRICE_USD) values ('alogliptin','It treats diabetes',21);

1 row created.

SQL> 
SQL> spool off;
SQL> insert into F21_S003_9_MEDICINE (M_NAME,MFG_DATE,QUANTITY) values ('Pramlintide',TO_DATE('2021-11-24','YYYY-MM-DD'),40);

1 row created.

SQL> insert into F21_S003_9_MEDICINE (M_NAME,MFG_DATE,QUANTITY) values ('alogliptin',TO_DATE('2021-11-25','YYYY-MM-DD'),40);

1 row created.

SQL> Spool off;
SQL> insert into F21_S003_9_DOCTOR (DOC_NAME,DOC_CONTACT) values ('Dr. Nomaan',19056714757);

1 row created.

SQL> insert into F21_S003_9_DOC_SPEC (SPEC_NAME,SPEC_TYPE,DOCTOR_ID) values ('Ear_Nose_Throat Doctor','ENT',215);
insert into F21_S003_9_DOC_SPEC (SPEC_NAME,SPEC_TYPE,DOCTOR_ID) values ('Ear_Nose_Throat Doctor','ENT',215)
*
ERROR at line 1:
ORA-02291: integrity constraint (JXJ4536.SYS_C00398672) violated - parent key 
not found 


SQL> spool off;
SQL> insert into F21_S003_9_DOC_SPEC (SPEC_NAME,SPEC_TYPE,DOCTOR_ID) values ('Ear_Nose_Throat Doctor','ENT',221);

1 row created.

SQL> spool off;
SQL> insert into F21_S003_9_DECIDES (TREATMENT_ID,MEDICINE_ID,DISEASE_ID) values (301,1113,408);

1 row created.

SQL> insert into F21_S003_9_DECIDES (TREATMENT_ID,MEDICINE_ID,DISEASE_ID) values (302,1114,402);

1 row created.

SQL> insert into F21_S003_9_DECIDES (TREATMENT_ID,MEDICINE_ID,DISEASE_ID) values (303,1115,410);

1 row created.

SQL> insert into F21_S003_9_DECIDES (TREATMENT_ID,MEDICINE_ID,DISEASE_ID) values (304,1116,413);

1 row created.

SQL> insert into F21_S003_9_DECIDES (TREATMENT_ID,MEDICINE_ID,DISEASE_ID) values (305,1117,412);

1 row created.

SQL> insert into F21_S003_9_DECIDES (TREATMENT_ID,MEDICINE_ID,DISEASE_ID) values (306,1118,414);

1 row created.

SQL> insert into F21_S003_9_DECIDES (TREATMENT_ID,MEDICINE_ID,DISEASE_ID) values (307,1119,415);

1 row created.

SQL> insert into F21_S003_9_DECIDES (TREATMENT_ID,MEDICINE_ID,DISEASE_ID) values (308,1120,401);

1 row created.

SQL> insert into F21_S003_9_DECIDES (TREATMENT_ID,MEDICINE_ID,DISEASE_ID) values (309,1121,403);

1 row created.

SQL> insert into F21_S003_9_DECIDES (TREATMENT_ID,MEDICINE_ID,DISEASE_ID) values (310,1122,409);

1 row created.

SQL> insert into F21_S003_9_DECIDES (TREATMENT_ID,MEDICINE_ID,DISEASE_ID) values (311,1123,404);

1 row created.

SQL> insert into F21_S003_9_DECIDES (TREATMENT_ID,MEDICINE_ID,DISEASE_ID) values (312,1124,406);

1 row created.

SQL> insert into F21_S003_9_DECIDES (TREATMENT_ID,MEDICINE_ID,DISEASE_ID) values (318,1125,405);

1 row created.

SQL> insert into F21_S003_9_DECIDES (TREATMENT_ID,MEDICINE_ID,DISEASE_ID) values (319,1126,407);

1 row created.

SQL> insert into F21_S003_9_DECIDES (TREATMENT_ID,MEDICINE_ID,DISEASE_ID) values (321,1127,408);

1 row created.

SQL> insert into F21_S003_9_DECIDES (TREATMENT_ID,MEDICINE_ID,DISEASE_ID) values (322,1128,402);

1 row created.

SQL> insert into F21_S003_9_DECIDES (TREATMENT_ID,MEDICINE_ID,DISEASE_ID) values (323,1129,410);

1 row created.

SQL> insert into F21_S003_9_DECIDES (TREATMENT_ID,MEDICINE_ID,DISEASE_ID) values (324,1130,413);

1 row created.

SQL> insert into F21_S003_9_DECIDES (TREATMENT_ID,MEDICINE_ID,DISEASE_ID) values (325,1131,412);

1 row created.

SQL> insert into F21_S003_9_DECIDES (TREATMENT_ID,MEDICINE_ID,DISEASE_ID) values (326,1132,414);

1 row created.

SQL> insert into F21_S003_9_DECIDES (TREATMENT_ID,MEDICINE_ID,DISEASE_ID) values (327,1133,415);

1 row created.

SQL> insert into F21_S003_9_DECIDES (TREATMENT_ID,MEDICINE_ID,DISEASE_ID) values (328,1134,401);

1 row created.

SQL> insert into F21_S003_9_DECIDES (TREATMENT_ID,MEDICINE_ID,DISEASE_ID) values (329,1135,403);

1 row created.

SQL> insert into F21_S003_9_DECIDES (TREATMENT_ID,MEDICINE_ID,DISEASE_ID) values (330,1136,409);

1 row created.

SQL> insert into F21_S003_9_DECIDES (TREATMENT_ID,MEDICINE_ID,DISEASE_ID) values (331,1137,404);

1 row created.

SQL> insert into F21_S003_9_DECIDES (TREATMENT_ID,MEDICINE_ID,DISEASE_ID) values (332,1138,406);

1 row created.

SQL> insert into F21_S003_9_DECIDES (TREATMENT_ID,MEDICINE_ID,DISEASE_ID) values (333,1139,405);

1 row created.

SQL> insert into F21_S003_9_DECIDES (TREATMENT_ID,MEDICINE_ID,DISEASE_ID) values (334,1140,407);

1 row created.

SQL> insert into F21_S003_9_DECIDES (TREATMENT_ID,MEDICINE_ID,DISEASE_ID) values (335,1306,411);
insert into F21_S003_9_DECIDES (TREATMENT_ID,MEDICINE_ID,DISEASE_ID) values (335,1306,411)
*
ERROR at line 1:
ORA-02291: integrity constraint (JXJ4536.SYS_C00398834) violated - parent key 
not found 


SQL> insert into F21_S003_9_DECIDES (TREATMENT_ID,MEDICINE_ID,DISEASE_ID) values (336,1307,411);
insert into F21_S003_9_DECIDES (TREATMENT_ID,MEDICINE_ID,DISEASE_ID) values (336,1307,411)
*
ERROR at line 1:
ORA-02291: integrity constraint (JXJ4536.SYS_C00398834) violated - parent key 
not found 


SQL> 
SQL> spool off;
SQL> insert into F21_S003_9_APPOINTMENT (SYMPTOMS,BK_DATE,PATIENT_ID,DOCTOR_ID) values ('fever_ dizziness_ loss of apetite',TO_DATE('2021/11/09 9:00:00', 'yyyy/mm/dd hh24:mi:ss'),221,206);

1 row created.

SQL> insert into F21_S003_9_APPOINTMENT (SYMPTOMS,BK_DATE,PATIENT_ID,DOCTOR_ID) values ('Asthma_ Pneumonia_ Anxiety',TO_DATE('2021/11/09 14:00:00', 'yyyy/mm/dd hh24:mi:ss'),222,202);

1 row created.

SQL> insert into F21_S003_9_APPOINTMENT (SYMPTOMS,BK_DATE,PATIENT_ID,DOCTOR_ID) values ('fever_ dizziness_ loss of apetite',TO_DATE('2021/11/09 10:00:00', 'yyyy/mm/dd hh24:mi:ss'),223,206);

1 row created.

SQL> insert into F21_S003_9_APPOINTMENT (SYMPTOMS,BK_DATE,PATIENT_ID,DOCTOR_ID) values ('dry mouth_ feeling thirsty_ feeling tired',TO_DATE('2021/11/09 11:00:00', 'yyyy/mm/dd hh24:mi:ss'),224,208);

1 row created.

SQL> insert into F21_S003_9_APPOINTMENT (SYMPTOMS,BK_DATE,PATIENT_ID,DOCTOR_ID) values ('Headache_ irritability_ distorted vision',TO_DATE('2021/11/09 11:00:00', 'yyyy/mm/dd hh24:mi:ss'),225,203);

1 row created.

SQL> insert into F21_S003_9_APPOINTMENT (SYMPTOMS,BK_DATE,PATIENT_ID,DOCTOR_ID) values ('swollen gums_ bad breath_ sensitive teeth',TO_DATE('2021/11/09 9:00:00', 'yyyy/mm/dd hh24:mi:ss'),226,211);

1 row created.

SQL> insert into F21_S003_9_APPOINTMENT (SYMPTOMS,BK_DATE,PATIENT_ID,DOCTOR_ID) values ('Numbness_ pressure in ear_ hearing loss',TO_DATE('2021/11/09 15:00:00', 'yyyy/mm/dd hh24:mi:ss'),227,205);

1 row created.

SQL> insert into F21_S003_9_APPOINTMENT (SYMPTOMS,BK_DATE,PATIENT_ID,DOCTOR_ID) values ('constipation_ hoarseness_ dry skin',TO_DATE('2021/11/09 16:00:00', 'yyyy/mm/dd hh24:mi:ss'),228,204);

1 row created.

SQL> insert into F21_S003_9_APPOINTMENT (SYMPTOMS,BK_DATE,PATIENT_ID,DOCTOR_ID) values ('fever_ dizziness_ loss of apetite',TO_DATE('2021/11/09 15:00:00', 'yyyy/mm/dd hh24:mi:ss'),229,206);

1 row created.

SQL> insert into F21_S003_9_APPOINTMENT (SYMPTOMS,BK_DATE,PATIENT_ID,DOCTOR_ID) values ('Ear pain_ fussiness_ tugging at ear',TO_DATE('2021/11/09 16:00:00', 'yyyy/mm/dd hh24:mi:ss'),230,223);

1 row created.

SQL> insert into F21_S003_9_APPOINTMENT (SYMPTOMS,BK_DATE,PATIENT_ID,DOCTOR_ID) values ('itchiness_ skin redness_ infection at areas of broken skin',TO_DATE('2021/11/09 14:00:00', 'yyyy/mm/dd hh24:mi:ss'),231,207);

1 row created.

SQL> insert into F21_S003_9_APPOINTMENT (SYMPTOMS,BK_DATE,PATIENT_ID,DOCTOR_ID) values ('Numbness_ pressure in ear_ hearing loss',TO_DATE('2021/11/09 10:00:00', 'yyyy/mm/dd hh24:mi:ss'),232,205);

1 row created.

SQL> insert into F21_S003_9_APPOINTMENT (SYMPTOMS,BK_DATE,PATIENT_ID,DOCTOR_ID) values ('Headache_ irritability_ distorted vision',TO_DATE('2021/11/09 11:00:00', 'yyyy/mm/dd hh24:mi:ss'),233,203);

1 row created.

SQL> insert into F21_S003_9_APPOINTMENT (SYMPTOMS,BK_DATE,PATIENT_ID,DOCTOR_ID) values ('toothache_tooth sensitivity_ pits in teeth',TO_DATE('2021/11/10 9:00:00', 'yyyy/mm/dd hh24:mi:ss'),234,212);

1 row created.

SQL> insert into F21_S003_9_APPOINTMENT (SYMPTOMS,BK_DATE,PATIENT_ID,DOCTOR_ID) values ('constipation_ hoarseness_ dry skin',TO_DATE('2021/11/10 14:00:00', 'yyyy/mm/dd hh24:mi:ss'),235,204);

1 row created.

SQL> insert into F21_S003_9_APPOINTMENT (SYMPTOMS,BK_DATE,PATIENT_ID,DOCTOR_ID) values ('redness_ swelling_ stiffness',TO_DATE('2021/11/10 10:00:00', 'yyyy/mm/dd hh24:mi:ss'),236,213);

1 row created.

SQL> insert into F21_S003_9_APPOINTMENT (SYMPTOMS,BK_DATE,PATIENT_ID,DOCTOR_ID) values ('fever_ dizziness_ loss of apetite',TO_DATE('2021/11/10 11:00:00', 'yyyy/mm/dd hh24:mi:ss'),237,206);

1 row created.

SQL> insert into F21_S003_9_APPOINTMENT (SYMPTOMS,BK_DATE,PATIENT_ID,DOCTOR_ID) values ('Asthma_ Pneumonia_ Anxiety',TO_DATE('2021/11/10 11:00:00', 'yyyy/mm/dd hh24:mi:ss'),238,202);

1 row created.

SQL> insert into F21_S003_9_APPOINTMENT (SYMPTOMS,BK_DATE,PATIENT_ID,DOCTOR_ID) values ('running nose_ sneezing_congestion',TO_DATE('2021/11/10 9:00:00', 'yyyy/mm/dd hh24:mi:ss'),239,209);

1 row created.

SQL> insert into F21_S003_9_APPOINTMENT (SYMPTOMS,BK_DATE,PATIENT_ID,DOCTOR_ID) values ('Nausea_ shortness of breadth_ discomfort',TO_DATE('2021/11/10 15:00:00', 'yyyy/mm/dd hh24:mi:ss'),240,201);

1 row created.

SQL> insert into F21_S003_9_APPOINTMENT (SYMPTOMS,BK_DATE,PATIENT_ID,DOCTOR_ID) values ('dry mouth_ feeling thirsty_ feeling tired',TO_DATE('2021/11/10 14:00:00', 'yyyy/mm/dd hh24:mi:ss'),241,208);

1 row created.

SQL> insert into F21_S003_9_APPOINTMENT (SYMPTOMS,BK_DATE,PATIENT_ID,DOCTOR_ID) values ('Numbness_ pressure in ear_ hearing loss',TO_DATE('2021/11/10 15:00:00', 'yyyy/mm/dd hh24:mi:ss'),242,205);

1 row created.

SQL> insert into F21_S003_9_APPOINTMENT (SYMPTOMS,BK_DATE,PATIENT_ID,DOCTOR_ID) values ('itchiness_ skin redness_ infection at areas of broken skin',TO_DATE('2021/11/10 16:00:00', 'yyyy/mm/dd hh24:mi:ss'),243,207);

1 row created.

SQL> insert into F21_S003_9_APPOINTMENT (SYMPTOMS,BK_DATE,PATIENT_ID,DOCTOR_ID) values ('constipation_ hoarseness_ dry skin',TO_DATE('2021/11/10 11:00:00', 'yyyy/mm/dd hh24:mi:ss'),244,204);

1 row created.

SQL> insert into F21_S003_9_APPOINTMENT (SYMPTOMS,BK_DATE,PATIENT_ID,DOCTOR_ID) values (' very hungry_ dry skin_blurry vision',TO_DATE('2021/11/10 10:00:00', 'yyyy/mm/dd hh24:mi:ss'),245,210);

1 row created.

SQL> insert into F21_S003_9_APPOINTMENT (SYMPTOMS,BK_DATE,PATIENT_ID,DOCTOR_ID) values ('constipation_ hoarseness_ dry skin',TO_DATE('2021/11/10 16:00:00', 'yyyy/mm/dd hh24:mi:ss'),246,204);

1 row created.

SQL> insert into F21_S003_9_APPOINTMENT (SYMPTOMS,BK_DATE,PATIENT_ID,DOCTOR_ID) values ('toothache_tooth sensitivity_ pits in teeth',TO_DATE('2021/11/11 9:00:00', 'yyyy/mm/dd hh24:mi:ss'),247,212);

1 row created.

SQL> insert into F21_S003_9_APPOINTMENT (SYMPTOMS,BK_DATE,PATIENT_ID,DOCTOR_ID) values ('fever_ dizziness_ loss of apetite',TO_DATE('2021/11/11 14:00:00', 'yyyy/mm/dd hh24:mi:ss'),248,206);

1 row created.

SQL> insert into F21_S003_9_APPOINTMENT (SYMPTOMS,BK_DATE,PATIENT_ID,DOCTOR_ID) values ('swollen gums_ bad breath_ sensitive teeth',TO_DATE('2021/11/11 10:00:00', 'yyyy/mm/dd hh24:mi:ss'),249,211);

1 row created.

SQL> insert into F21_S003_9_APPOINTMENT (SYMPTOMS,BK_DATE,PATIENT_ID,DOCTOR_ID) values ('running nose_ sneezing_congestion',TO_DATE('2021/11/11 11:00:00', 'yyyy/mm/dd hh24:mi:ss'),250,209);

1 row created.

SQL> insert into F21_S003_9_APPOINTMENT (SYMPTOMS,BK_DATE,PATIENT_ID,DOCTOR_ID) values ('redness_ swelling_ stiffness',TO_DATE('2021/11/11 11:00:00', 'yyyy/mm/dd hh24:mi:ss'),251,213);

1 row created.

SQL> insert into F21_S003_9_APPOINTMENT (SYMPTOMS,BK_DATE,PATIENT_ID,DOCTOR_ID) values ('Headache_ irritability_ distorted vision',TO_DATE('2021/11/11 9:00:00', 'yyyy/mm/dd hh24:mi:ss'),252,203);

1 row created.

SQL> insert into F21_S003_9_APPOINTMENT (SYMPTOMS,BK_DATE,PATIENT_ID,DOCTOR_ID) values ('unable to bear weight_ bruising_ sudden pain',TO_DATE('2021/11/11 15:00:00', 'yyyy/mm/dd hh24:mi:ss'),253,214);

1 row created.

SQL> insert into F21_S003_9_APPOINTMENT (SYMPTOMS,BK_DATE,PATIENT_ID,DOCTOR_ID) values ('dry mouth_ feeling thirsty_ feeling tired',TO_DATE('2021/11/11 14:00:00', 'yyyy/mm/dd hh24:mi:ss'),254,208);

1 row created.

SQL> insert into F21_S003_9_APPOINTMENT (SYMPTOMS,BK_DATE,PATIENT_ID,DOCTOR_ID) values ('Ear pain_ fussiness_ tugging at ear',TO_DATE('2021/11/11 15:00:00', 'yyyy/mm/dd hh24:mi:ss'),255,223);

1 row created.

SQL> insert into F21_S003_9_APPOINTMENT (SYMPTOMS,BK_DATE,PATIENT_ID,DOCTOR_ID) values ('fever_ dizziness_ loss of apetite',TO_DATE('2021/11/11 16:00:00', 'yyyy/mm/dd hh24:mi:ss'),256,206);

1 row created.

SQL> insert into F21_S003_9_APPOINTMENT (SYMPTOMS,BK_DATE,PATIENT_ID,DOCTOR_ID) values ('itchiness_ skin redness_ infection at areas of broken skin',TO_DATE('2021/11/11 11:00:00', 'yyyy/mm/dd hh24:mi:ss'),257,207);

1 row created.

SQL> insert into F21_S003_9_APPOINTMENT (SYMPTOMS,BK_DATE,PATIENT_ID,DOCTOR_ID) values ('unable to bear weight_ bruising_ sudden pain',TO_DATE('2021/11/11 10:00:00', 'yyyy/mm/dd hh24:mi:ss'),258,214);

1 row created.

SQL> insert into F21_S003_9_APPOINTMENT (SYMPTOMS,BK_DATE,PATIENT_ID,DOCTOR_ID) values ('running nose_ sneezing_congestion',TO_DATE('2021/11/11 16:00:00', 'yyyy/mm/dd hh24:mi:ss'),259,209);

1 row created.

SQL> insert into F21_S003_9_APPOINTMENT (SYMPTOMS,BK_DATE,PATIENT_ID,DOCTOR_ID) values ('fever_ dizziness_ loss of apetite',TO_DATE('2021/11/12 9:00:00', 'yyyy/mm/dd hh24:mi:ss'),260,206);

1 row created.

SQL> insert into F21_S003_9_APPOINTMENT (SYMPTOMS,BK_DATE,PATIENT_ID,DOCTOR_ID) values ('Numbness_ pressure in ear_ hearing loss',TO_DATE('2021/11/12 14:00:00', 'yyyy/mm/dd hh24:mi:ss'),221,205);

1 row created.

SQL> insert into F21_S003_9_APPOINTMENT (SYMPTOMS,BK_DATE,PATIENT_ID,DOCTOR_ID) values (' very hungry_ dry skin_blurry vision',TO_DATE('2021/11/12 10:00:00', 'yyyy/mm/dd hh24:mi:ss'),222,210);

1 row created.

SQL> insert into F21_S003_9_APPOINTMENT (SYMPTOMS,BK_DATE,PATIENT_ID,DOCTOR_ID) values ('redness_ swelling_ stiffness',TO_DATE('2021/11/12 11:00:00', 'yyyy/mm/dd hh24:mi:ss'),223,213);

1 row created.

SQL> insert into F21_S003_9_APPOINTMENT (SYMPTOMS,BK_DATE,PATIENT_ID,DOCTOR_ID) values ('Headache_ irritability_ distorted vision',TO_DATE('2021/11/12 11:00:00', 'yyyy/mm/dd hh24:mi:ss'),224,203);

1 row created.

SQL> insert into F21_S003_9_APPOINTMENT (SYMPTOMS,BK_DATE,PATIENT_ID,DOCTOR_ID) values ('unable to bear weight_ bruising_ sudden pain',TO_DATE('2021/11/12 9:00:00', 'yyyy/mm/dd hh24:mi:ss'),225,214);

1 row created.

SQL> insert into F21_S003_9_APPOINTMENT (SYMPTOMS,BK_DATE,PATIENT_ID,DOCTOR_ID) values ('running nose_ sneezing_congestion',TO_DATE('2021/11/12 15:00:00', 'yyyy/mm/dd hh24:mi:ss'),226,209);

1 row created.

SQL> insert into F21_S003_9_APPOINTMENT (SYMPTOMS,BK_DATE,PATIENT_ID,DOCTOR_ID) values ('Asthma_ Pneumonia_ Anxiety',TO_DATE('2021/11/12 16:00:00', 'yyyy/mm/dd hh24:mi:ss'),227,202);

1 row created.

SQL> insert into F21_S003_9_APPOINTMENT (SYMPTOMS,BK_DATE,PATIENT_ID,DOCTOR_ID) values ('swollen gums_ bad breath_ sensitive teeth',TO_DATE('2021/11/12 15:00:00', 'yyyy/mm/dd hh24:mi:ss'),228,211);

1 row created.

SQL> insert into F21_S003_9_APPOINTMENT (SYMPTOMS,BK_DATE,PATIENT_ID,DOCTOR_ID) values ('fever_ dizziness_ loss of apetite',TO_DATE('2021/11/12 16:00:00', 'yyyy/mm/dd hh24:mi:ss'),229,206);

1 row created.

SQL> insert into F21_S003_9_APPOINTMENT (SYMPTOMS,BK_DATE,PATIENT_ID,DOCTOR_ID) values ('toothache_tooth sensitivity_ pits in teeth',TO_DATE('2021/11/12 14:00:00', 'yyyy/mm/dd hh24:mi:ss'),230,212);

1 row created.

SQL> insert into F21_S003_9_APPOINTMENT (SYMPTOMS,BK_DATE,PATIENT_ID,DOCTOR_ID) values ('fever_ dizziness_ loss of apetite',TO_DATE('2021/11/12 10:00:00', 'yyyy/mm/dd hh24:mi:ss'),231,206);

1 row created.

SQL> insert into F21_S003_9_APPOINTMENT (SYMPTOMS,BK_DATE,PATIENT_ID,DOCTOR_ID) values ('running nose_ sneezing_congestion',TO_DATE('2021/11/12 11:00:00', 'yyyy/mm/dd hh24:mi:ss'),221,209);
  2  --inserting the values to the APPOINTMENT table

1 row created.

SQL> select count(*) from F21_S003_9_APPOINTMENT;

  COUNT(*)                                                                      
----------                                                                      
        52                                                                      

SQL> spool off;
SQL> insert into F21_S003_9_SENDS (TREAT_ID,APPOINT_ID) values (319,312);

1 row created.

SQL> spool off;
SQL> insert into F21_S003_9_SENDS (TREAT_ID,APPOINT_ID) values (302,313);

1 row created.

SQL> insert into F21_S003_9_SENDS (TREAT_ID,APPOINT_ID) values (319,314);

1 row created.

SQL> insert into F21_S003_9_SENDS (TREAT_ID,APPOINT_ID) values (310,315);

1 row created.

SQL> insert into F21_S003_9_SENDS (treat_id,appoint_id) values (309,316);

1 row created.

SQL> insert into F21_S003_9_SENDS (treat_id,appoint_id) values (304,317);

1 row created.

SQL> insert into F21_S003_9_SENDS (treat_id,appoint_id) values (318,318);

1 row created.

SQL> insert into F21_S003_9_SENDS (treat_id,appoint_id) values (312,319);

1 row created.

SQL> insert into F21_S003_9_SENDS (treat_id,appoint_id) values (319,320);

1 row created.

SQL> insert into F21_S003_9_SENDS (treat_id,appoint_id) values (311,321);

1 row created.

SQL> insert into F21_S003_9_SENDS (treat_id,appoint_id) values (303,322);

1 row created.

SQL> insert into F21_S003_9_SENDS (treat_id,appoint_id) values (318,323);

1 row created.

SQL> insert into F21_S003_9_SENDS (treat_id,appoint_id) values (309,324);

1 row created.

SQL> insert into F21_S003_9_SENDS (treat_id,appoint_id) values (305,325);

1 row created.

SQL> insert into F21_S003_9_SENDS (treat_id,appoint_id) values (312,326);

1 row created.

SQL> insert into F21_S003_9_SENDS (treat_id,appoint_id) values (306,327);

1 row created.

SQL> insert into F21_S003_9_SENDS (treat_id,appoint_id) values (319,328);

1 row created.

SQL> insert into F21_S003_9_SENDS (treat_id,appoint_id) values (302,329);

1 row created.

SQL> insert into F21_S003_9_SENDS (treat_id,appoint_id) values (301,330);

1 row created.

SQL> insert into F21_S003_9_SENDS (treat_id,appoint_id) values (308,331);

1 row created.

SQL> insert into F21_S003_9_SENDS (treat_id,appoint_id) values (310,332);

1 row created.

SQL> insert into F21_S003_9_SENDS (treat_id,appoint_id) values (318,333);

1 row created.

SQL> insert into F21_S003_9_SENDS (treat_id,appoint_id) values (303,334);

1 row created.

SQL> insert into F21_S003_9_SENDS (treat_id,appoint_id) values (312,335);

1 row created.

SQL> insert into F21_S003_9_SENDS (treat_id,appoint_id) values (335,336);

1 row created.

SQL> insert into F21_S003_9_SENDS (treat_id,appoint_id) values (312,337);

1 row created.

SQL> insert into F21_S003_9_SENDS (treat_id,appoint_id) values (305,338);

1 row created.

SQL> insert into F21_S003_9_SENDS (treat_id,appoint_id) values (319,339);

1 row created.

SQL> insert into F21_S003_9_SENDS (treat_id,appoint_id) values (304,340);

1 row created.

SQL> insert into F21_S003_9_SENDS (treat_id,appoint_id) values (301,341);

1 row created.

SQL> insert into F21_S003_9_SENDS (treat_id,appoint_id) values (306,342);

1 row created.

SQL> insert into F21_S003_9_SENDS (treat_id,appoint_id) values (309,343);

1 row created.

SQL> insert into F21_S003_9_SENDS (treat_id,appoint_id) values (307,344);

1 row created.

SQL> insert into F21_S003_9_SENDS (treat_id,appoint_id) values (310,345);

1 row created.

SQL> insert into F21_S003_9_SENDS (treat_id,appoint_id) values (311,346);

1 row created.

SQL> insert into F21_S003_9_SENDS (treat_id,appoint_id) values (319,347);

1 row created.

SQL> insert into F21_S003_9_SENDS (treat_id,appoint_id) values (303,348);

1 row created.

SQL> insert into F21_S003_9_SENDS (treat_id,appoint_id) values (307,349);

1 row created.

SQL> insert into F21_S003_9_SENDS (treat_id,appoint_id) values (301,350);

1 row created.

SQL> insert into F21_S003_9_SENDS (treat_id,appoint_id) values (319,351);

1 row created.

SQL> insert into F21_S003_9_SENDS (treat_id,appoint_id) values (318,352);

1 row created.

SQL> insert into F21_S003_9_SENDS (treat_id,appoint_id) values (335,353);

1 row created.

SQL> insert into F21_S003_9_SENDS (treat_id,appoint_id) values (306,354);

1 row created.

SQL> insert into F21_S003_9_SENDS (treat_id,appoint_id) values (309,355);

1 row created.

SQL> insert into F21_S003_9_SENDS (treat_id,appoint_id) values (307,356);

1 row created.

SQL> insert into F21_S003_9_SENDS (treat_id,appoint_id) values (301,357);

1 row created.

SQL> insert into F21_S003_9_SENDS (treat_id,appoint_id) values (302,358);

1 row created.

SQL> insert into F21_S003_9_SENDS (treat_id,appoint_id) values (304,359);

1 row created.

SQL> insert into F21_S003_9_SENDS (treat_id,appoint_id) values (319,360);

1 row created.

SQL> insert into F21_S003_9_SENDS (treat_id,appoint_id) values (305,361);

1 row created.

SQL> insert into F21_S003_9_SENDS (treat_id,appoint_id) values (319,362);

1 row created.

SQL> insert into F21_S003_9_SENDS (treat_id,appoint_id) values (301,363);
  2  --inserting the values to the sends table

1 row created.

SQL> 
SQL> 
SQL> spool off;
