SQL> Drop table F21_S003_9_PROVIDES; --dropped the table provides to add sends table.

Table dropped.

SQL> spool off;
SQL> drop table F21_S003_9_EMR; --dropped the table EMR to add more attributes and created it again

Table dropped.

SQL> spool off;
